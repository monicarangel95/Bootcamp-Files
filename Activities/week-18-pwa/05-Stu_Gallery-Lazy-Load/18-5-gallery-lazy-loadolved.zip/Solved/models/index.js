module.exports = {
  Image: require("./image")
};
