# **Instructions**

* For the table favorite_foods...

  * Create the column "food" which can take in a 50 character string and cannot be NULL
  * Create the column "score" which can take in an integer

* For the table favorite_songs...

  * Create the column "song" which can take in a 100 character string and cannot be NULL
  * Create the column "artist" which can take in a 50 character string
  * Create the column "score" which can take in an integer

* For the table favorite_movies...

  * Create a numeric column called "id" which automatically increments and cannot be null
  * Create the column "movie" which can take in a string and cannot be NULL
  * Create the column "five_times" which can take in a boolean
  * create the column "score" which can take in an integer
  * Set the primary key of the table to id

* BONUS: Go online and look into how one might go about adding data into a table.
